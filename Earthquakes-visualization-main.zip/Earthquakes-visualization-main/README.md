# Earthquakes-visualization

Single-page website analyzing the global evolution of strong earthquakes from 1965 to 2016. The data was taken from Kaggle, on this link: https://www.kaggle.com/usgs/earthquake-database.

